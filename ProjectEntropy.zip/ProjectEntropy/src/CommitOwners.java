import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
class CommitOwners {

    public static class Employee {
        String id;
        String surname;
        String name;

        Employee(String id, String surname, String name) {
            this.id = id;
            this.surname = surname;
            this.name = name;
        }

        @Override
        public String toString() {
            return id + "," + surname + "," + name;
        }
    }

    static Map<String, Employee> employeeMap = new HashMap<>();
    static List<String> bestSequence = new ArrayList<>();
    static int totalDecompositions = 0;

    public static void main(String[] args) {
        if (args.length < 2) {
            System.err.println("Usage: java CommitOwners <employee_file> <weld_string>");
            System.exit(1);
        }

        String filename = args[0]; // e.g., src/data/empl.txt
        String weld = args[1];     // e.g., "1234567891015..."

        readEmployees(filename);
        List<String> currentPath = new ArrayList<>();
        findDecomposition(weld, 0, currentPath);

        if (totalDecompositions == 0) {
            System.out.println("No valid decomposition found.");
            return;
        }

        // Output best sequence
        System.out.println("Detected Committers:");
        for (String id : bestSequence) {
            System.out.println(employeeMap.get(id));
        }

        System.out.println("Total Valid Decompositions: " + totalDecompositions);
    }
    private static void readEmployees(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.trim().split(",");
                if (parts.length == 3 && parts[0].matches("\\d+")) {
                    Employee emp = new Employee(parts[0], parts[1], parts[2]);
                    employeeMap.put(parts[0], emp);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading employee file.");
            e.printStackTrace();
            System.exit(1);
        }
    }

    private static void findDecomposition(String weld, int index, List<String> currentPath) {
        if (index == weld.length()) {
            totalDecompositions++;
            if (currentPath.size() > bestSequence.size()) {
                bestSequence = new ArrayList<>(currentPath);
            }
            return;
        }

        for (int i = index + 1; i <= weld.length(); i++) {
            String prefix = weld.substring(index, i);
            if (employeeMap.containsKey(prefix)) {
                currentPath.add(prefix);
                findDecomposition(weld, i, currentPath);
                currentPath.remove(currentPath.size() - 1); // backtrack
            }
        }
    }
}
