

import java.io.*;
        import java.nio.file.*;
        import java.util.*;

public class EntropyAnalyzer {

    public static void main(String[] args) throws IOException {
        // Prompt user immediately
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a sentence to detect its language: ");
        String userInput = scanner.nextLine();
        scanner.close();

        // Load text files
        Path albPath1 = Paths.get("src","data", "alb.txt");
        Path albPath2 = Paths.get("src", "data", "alb1.txt");
        Path engPath = Paths.get("src","data", "eng.txt");

        String albContent1 = Files.readString(albPath1);
        String albContent2 = Files.readString(albPath2);
        String engContent = Files.readString(engPath);

        String fullAlbanian = albContent1 + albContent2;
        String cleanAlbanian = cleanText(fullAlbanian);
        String cleanEnglish = cleanText(engContent);

        PrintWriter resultOut = new PrintWriter("src/data/results.txt");

        // Analyze Albanian
        analyzeLanguage("Albanian", cleanAlbanian, resultOut);
        // Analyze English
        analyzeLanguage("English", cleanEnglish, resultOut);

        // Language detection
        Map<String, Integer> albBigrams = countNgrams(cleanAlbanian, 2);
        Map<String, Integer> engBigrams = countNgrams(cleanEnglish, 2);
        String cleanedInput = cleanText(userInput);
        String detectedLang = detectLanguage(cleanedInput, albBigrams, engBigrams);

        resultOut.println("\nLanguage Classification");
        resultOut.println("Sentence: " + userInput);
        resultOut.println("Detected language: " + detectedLang);

        resultOut.close();
    }

    public static void analyzeLanguage(String label, String text, PrintWriter out) {
        out.println("Language: " + label + " =====\n");

        for (int n = 0; n <= 10; n++) {
            out.println("--- " + n + "-gram model ---");
            Map<String, Integer> ngramCounts = countNgrams(text, n);

            int totalTokens = ngramCounts.values().stream().mapToInt(i -> i).sum();
            double entropy = calculateEntropy(ngramCounts, totalTokens);

            out.printf("Entropy: %.4f bits%n", entropy);
            out.println("Total tokens: " + totalTokens);

            List<Map.Entry<String, Integer>> sorted = new ArrayList<>(ngramCounts.entrySet());
            sorted.sort((a, b) -> b.getValue() - a.getValue());

            out.println("Most frequent 5 tokens:");
            for (int i = 0; i < Math.min(5, sorted.size()); i++) {
                out.println(sorted.get(i).getKey() + " = " + sorted.get(i).getValue());
            }

            out.println("Least frequent 5 tokens:");
            for (int i = sorted.size() - 1; i >= Math.max(0, sorted.size() - 5); i--) {
                out.println(sorted.get(i).getKey() + " = " + sorted.get(i).getValue());
            }

            out.println();
        }
    }

    public static String cleanText(String text) {
        return text.toLowerCase()
                .replace("�", "")
                .replaceAll("[^a-zA-ZçÇëË\\s]", "")
                .replaceAll("\\s+", "");
    }

    public static Map<String, Integer> countNgrams(String text, int n) {
        Map<String, Integer> freqMap = new HashMap<>();
        if (n == 0) {
            freqMap.put("uniform", text.length());
        } else {
            for (int i = 0; i <= text.length() - n; i++) {
                String gram = text.substring(i, i + n);
                freqMap.put(gram, freqMap.getOrDefault(gram, 0) + 1);
            }
        }
        return freqMap;
    }

    public static double calculateEntropy(Map<String, Integer> freqMap, int total) {
        double entropy = 0.0;
        for (int count : freqMap.values()) {
            double p = (double) count / total;
            entropy -= p * (Math.log(p) / Math.log(2));
        }
        return entropy;
    }

    public static String detectLanguage(String sentence, Map<String, Integer> alb, Map<String, Integer> eng) {
        int albScore = 0, engScore = 0;
        for (int i = 0; i <= sentence.length() - 2; i++) {
            String bg = sentence.substring(i, i + 2);
            albScore += alb.getOrDefault(bg, 0);
            engScore += eng.getOrDefault(bg, 0);
        }
        return albScore > engScore ? "Albanian" : "English";
    }
}
